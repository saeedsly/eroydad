# Third-party notices

## Vazirmatn variable font

Copyright 2015 The Vazirmatn Project Authors. Licensed under the SIL Open Font License 1.1 (OFL); see `frontend/public/assets/fonts/vazirmatn-OFL.txt` for the complete license text. Source: https://github.com/rastikerdar/vazirmatn

## qrcode-generator 2.0.4

Copyright (c) 2009-2011 Kazuhiko Arase. Licensed under the MIT License.
Source package: https://www.npmjs.com/package/qrcode-generator (2.0.4)

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY.
