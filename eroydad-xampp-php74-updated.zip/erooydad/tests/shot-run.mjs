import { createRequire } from 'module';
import path from 'path';
import { existsSync, mkdirSync } from 'fs';
const require = createRequire(import.meta.url);
const chromium = require('@sparticuz/chromium');
const lambdafs = require('@sparticuz/chromium/build/lambdafs.js');
const helper = require('@sparticuz/chromium/build/helper.js');
const binDir = path.join(path.dirname(require.resolve('@sparticuz/chromium/package.json')), 'bin');
const inflate = lambdafs.default ?? lambdafs;
if (!existsSync('/tmp/al2023/lib')) await inflate.inflate(path.join(binDir, 'al2023.tar.br'));
if (!existsSync('/tmp/fonts')) await inflate.inflate(path.join(binDir, 'fonts.tar.br'));
helper.setupLambdaEnvironment('/tmp/al2023/lib');
const puppeteer = require('puppeteer-core');
const BASE = 'http://127.0.0.1:8642';
const OUT = '/home/user/eroydad/screenshots';
mkdirSync(OUT, { recursive: true });
const browser = await puppeteer.launch({ executablePath: await chromium.executablePath(), args: chromium.args, headless: true });
const page = await browser.newPage();
await page.setViewport({ width: 1320, height: 900, deviceScaleFactor: 1 });
await page.goto(BASE + '/', { waitUntil: 'networkidle2' });
await new Promise(r => setTimeout(r, 800));
await page.screenshot({ path: OUT + '/theme-home.png' });
// اسکرین‌شات نیمهٔ پایین (بخش تیرهٔ درباره + پاورقی)
await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight * 0.55));
await new Promise(r => setTimeout(r, 600));
await page.screenshot({ path: OUT + '/theme-about.png' });
// موبایل
await page.setViewport({ width: 360, height: 740, deviceScaleFactor: 2 });
await page.goto(BASE + '/', { waitUntil: 'networkidle2' });
await new Promise(r => setTimeout(r, 600));
await page.screenshot({ path: OUT + '/theme-mobile.png' });
// صفحهٔ رویداد (فرم ثبت‌نام سریع)
const slug = await page.evaluate(async () => {
  const t = await (await fetch('/events')).text();
  const m = /\/events\/([a-z0-9-]{6,})/.exec(t);
  return m ? m[1] : '';
});
if (slug) {
  await page.setViewport({ width: 1320, height: 900, deviceScaleFactor: 1 });
  await page.goto(BASE + '/events/' + slug, { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 600));
  await page.screenshot({ path: OUT + '/theme-event.png' });
}
await browser.close();
console.log('shots done');
